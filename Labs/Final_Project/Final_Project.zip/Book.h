#ifndef TREE_H_INCLUDED
#define TREE_H_INCLUDED
#include <string>
#include <vector>
using namespace std;


class BookNode {
private:
    string title;
    string lastName;
    string firstName
    string genre;
    int price;
    int quantity_in_stock;
    int ISBN_number;
    TreeNode *parent;
    TreeNode *rightChild;
    TreeNode *leftChild;


class Tree {
public:
    Tree();
    virtual ~Tree();
    void printInventory();
    void printBargainBook(int price);
    //void printOnSale();
    void addBook(string title, string author, string genre, int price, int quantity_in_stock, int ISBN_number);
    void sellBook(int ISBN_number);



};
#endif // TREE_H_INCLUDED
